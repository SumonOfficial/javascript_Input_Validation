

function validateForm(){
    let name = document.myform.name;
    let email = document.myform.email;
    let telephone = document.myform.telephone;
    let notCall = document.myform.notCall;
    let subject = document.myform.subject;
    let Comment = document.myform.Comment;

  if(name.value==""){ 
      document.getElementById("state").innerHTML="please enter your name...";
      return false;
  }

  if(email.value==""){
      document.getElementById("state").innerHTML="please enter your e-mail..."
      return false;
  }

  if(email.value.indexOf("@",0)<0){
    document.getElementById("state").innerHTML="please enter valid E-mail addresh...";
    return false;
  }

  if(email.value.indexOf(".",0)<0){
    document.getElementById("state").innerHTML="please enter valid E-mail addresh...";
    return false;
  }

  if(telephone.value == "" && notCall.checked == false){
      document.getElementById("state").innerHTML="please enter your telephone no..."
      return false;
  }

  if(subject.selectedIndex < 1){
    document.getElementById("state").innerHTML="please Chosse a option..."
    return false;
  }

  if(Comment.value==""){
      document.getElementById("state").innerHTML="Please put a Comment...";
      return false;
  }
}


function enableDisable(box){
    
    if(box.checked == true){
        document.myform.telephone.disabled = true;
    }else{
        document.myform.telephone.disabled = false;
    }

}




